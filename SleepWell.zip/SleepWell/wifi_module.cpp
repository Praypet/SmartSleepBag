#include "wifi_module.h"
#include "audio_module.h"
#include <ArduinoJson.h>

WiFiModule::WiFiModule() 
    : state(WIFI_DISCONNECTED), 
      lastConnectAttempt(0), 
      lastUploadTime(0),
      connectStartTime(0) {}

void WiFiModule::begin() {
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(false);
}

void WiFiModule::loop() {
    // 处理连接中状态
    if (state == WIFI_CONNECTING) {
        wl_status_t status = WiFi.status();
        if (status == WL_CONNECTED) {
            state = WIFI_CONNECTED;
            Serial.printf("\nWiFi 已连接, IP: %s, RSSI: %d dBm\n", 
                         WiFi.localIP().toString().c_str(), WiFi.RSSI());
        } else if (status == WL_CONNECT_FAILED || status == WL_CONNECTION_LOST) {
            state = WIFI_ERROR;
            Serial.println("WiFi 连接失败或丢失");
        } else if (millis() - connectStartTime > WIFI_TIMEOUT * 1000) {
            state = WIFI_ERROR;
            Serial.println("WiFi 连接超时");
        }
    } 
    // 检查已连接状态是否断开
    else if (state == WIFI_CONNECTED) {
        if (WiFi.status() != WL_CONNECTED) {
            state = WIFI_DISCONNECTED;
            Serial.println("WiFi 连接断开");
        }
    }
    // 错误状态下的重连
    else if (state == WIFI_ERROR) {
        if (millis() - lastConnectAttempt > WIFI_RETRY_INTERVAL) {
            connect();  // 重试连接
        }
    }
    // 未连接状态下的重连
    else if (state == WIFI_DISCONNECTED) {
        if (millis() - lastConnectAttempt > WIFI_RETRY_INTERVAL) {
            connect();  // 尝试连接
        }
    }
}

// 非阻塞连接 - 只启动连接，不等待
bool WiFiModule::connect() {
    // 如果正在连接中，不再重复启动
    if (state == WIFI_CONNECTING) {
        return false;
    }
    
    // 如果已连接，直接返回成功
    if (WiFi.status() == WL_CONNECTED) {
        state = WIFI_CONNECTED;
        return true;
    }
    
    state = WIFI_CONNECTING;
    lastConnectAttempt = millis();
    connectStartTime = millis();
    
    Serial.printf("正在连接WiFi: %s (RSSI阈值检测)\n", WIFI_SSID);
    
    // 先检查WiFi信号强度
    int8_t rssi = WiFi.RSSI();
    if (rssi < -80) {
        Serial.printf("WiFi信号太弱: %d dBm，连接可能失败\n", rssi);
    }
    
    // 断开之前的连接
    WiFi.disconnect();
    delay(100);
    
    // 设置WiFi参数以提高连接成功率
    WiFi.setSleep(false); // 禁用WiFi省电模式
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    
    return true;
}

void WiFiModule::disconnect() {
    WiFi.disconnect(true);
    state = WIFI_DISCONNECTED;
}

// 其余函数保持不变...
bool WiFiModule::uploadAlert(const AlertPacket& alert) {
    if (state != WIFI_CONNECTED) return false;
    
    HTTPClient http;
    http.begin(wifiClient, SERVER_URL);
    http.addHeader("Content-Type", "application/json");
    
    StaticJsonDocument<512> doc;
    doc["type"] = "alert";
    doc["alert_type"] = alert.type;
    doc["timestamp"] = alert.timestamp;
    doc["body_temp"] = alert.body_temp;
    doc["env_temp"] = alert.env_temp;
    doc["env_humi"] = alert.env_humi;
    doc["detail"] = alert.detail;
    doc["audio_id"] = alert.audioId;
    
    String jsonString;
    serializeJson(doc, jsonString);
    int code = http.POST(jsonString);
    http.end();
    
    return (code == 200 || code == 201);
}

bool WiFiModule::uploadPVDFBatch(PVDFPacket* packets, int count) {
    if (count == 0) return true;
    if (state != WIFI_CONNECTED) return false;
    
    HTTPClient http;
    http.begin(wifiClient, SERVER_URL);
    http.addHeader("Content-Type", "application/json");
    
    // 动态计算JSON大小
    int estimatedSize = 1024 + count * PVDF_POINTS_PER_PACK * 6;
    DynamicJsonDocument doc(estimatedSize);
    
    doc["type"] = "pvdf_batch";
    JsonArray packetsArray = doc.createNestedArray("packets");
    
    for (int i = 0; i < count; i++) {
        JsonObject packetObj = packetsArray.createNestedObject();
        packetObj["ts"] = packets[i].timestamp;
        packetObj["body_temp"] = packets[i].body_temp;
        packetObj["env_temp"] = packets[i].env_temp;
        packetObj["env_humi"] = packets[i].env_humi;
        packetObj["temp_real"] = packets[i].temp_realtime ? 1 : 0;
        packetObj["env_real"] = packets[i].env_realtime ? 1 : 0;
        
        JsonArray dataArray = packetObj.createNestedArray("data");
        for (int j = 0; j < PVDF_POINTS_PER_PACK; j++) {
            dataArray.add(packets[i].points[j]);
        }
    }
    
    String jsonString;
    serializeJson(doc, jsonString);
    int code = http.POST(jsonString);
    http.end();
    
    return (code == 200 || code == 201);
}

bool WiFiModule::uploadAudioSegment(uint32_t audioId, const uint8_t* data, uint32_t size, uint8_t priority) {
    if (state != WIFI_CONNECTED) return false;
    
    HTTPClient http;
    http.begin(wifiClient, SERVER_URL);
    http.addHeader("Content-Type", "application/octet-stream");
    http.addHeader("X-Audio-ID", String(audioId));
    http.addHeader("X-Audio-Priority", String(priority));
    http.addHeader("X-Data-Type", "audio");
    
    int code = http.POST((uint8_t*)data, size);
    http.end();
    
    bool success = (code == 200 || code == 201);
    if (success) {
        Serial.printf("音频ID=%d上传成功，大小=%d字节\n", audioId, size);
    } else {
        Serial.printf("音频上传失败，HTTP代码：%d\n", code);
    }
    return success;
}

bool WiFiModule::uploadAlerts(QueueModule& queue) {
    if (state != WIFI_CONNECTED) return false;
    
    bool anySuccess = false;
    AlertPacket alert;
    
    while (queue.receiveAlert(alert, 0)) {
        if (uploadAlert(alert)) {
            Serial.printf("预警上传成功: %d\n", alert.type);
            anySuccess = true;
        } else {
            // 上传失败，重新放回队列
            queue.sendAlertWithAudio(alert.type, alert.detail,
                alert.body_temp, alert.env_temp,
                alert.env_humi, alert.audioId);
            return anySuccess;
        }
    }
    return anySuccess;
}

bool WiFiModule::uploadAudio(AudioModule& audio) {
    if (state != WIFI_CONNECTED) return false;
    
    bool anySuccess = false;
    int maxAttempts = 5;
    
    while (maxAttempts-- > 0) {
        uint8_t* audioData;
        uint32_t audioSize;
        uint32_t audioId;
        uint8_t audioPriority;
        
        if (!audio.getAudioForUpload(audioData, audioSize, audioId, audioPriority)) {
            break;
        }
        
        if (uploadAudioSegment(audioId, audioData, audioSize, audioPriority)) {
            audio.markAudioUploaded(audioId, true);
            anySuccess = true;
        } else {
            audio.markAudioUploaded(audioId, false);
            Serial.printf("音频ID=%d上传失败，稍后重试\n", audioId);
            break;
        }
    }
    return anySuccess;
}

bool WiFiModule::uploadPVDF(QueueModule& queue) {
    if (state != WIFI_CONNECTED) return false;
    
    PVDFPacket packets[UPLOAD_BATCH_SIZE];
    int count = 0;
    
    while (count < UPLOAD_BATCH_SIZE && queue.receivePVDF(packets[count], 0)) {
        count++;
    }
    
    if (count > 0) {
        if (uploadPVDFBatch(packets, count)) {
            Serial.printf("上传%d个PVDF数据包成功\n", count);
            lastUploadTime = millis();
            return true;
        } else {
            // 上传失败，重新放回队列
            for (int i = 0; i < count; i++) {
                queue.sendPVDF(packets[i]);
            }
            return false;
        }
    }
    return true;
}

bool WiFiModule::uploadData(QueueModule& queue) {
    if (state != WIFI_CONNECTED) return false;
    uploadAlerts(queue);
    uploadPVDF(queue);
    return true;
}

bool WiFiModule::uploadData(QueueModule& queue, AudioModule& audio) {
    if (state != WIFI_CONNECTED) return false;
    uploadAlerts(queue);
    uploadAudio(audio);
    uploadPVDF(queue);
    return true;
}

void WiFiModule::flushAll(QueueModule& queue, AudioModule& audio) {
    if (state != WIFI_CONNECTED) return;
    
    int maxAttempts = 30;
    while (maxAttempts-- > 0) {
        bool hasData = false;
        if (uploadAlerts(queue)) hasData = true;
        if (uploadAudio(audio)) hasData = true;
        if (uploadPVDF(queue)) hasData = true;
        if (!hasData) break;
        delay(10);
    }
}

const char* WiFiModule::stateToString(WiFiState state) {
    switch (state) {
        case WIFI_DISCONNECTED: return "未连接";
        case WIFI_CONNECTING: return "连接中";
        case WIFI_CONNECTED: return "已连接";
        case WIFI_ERROR: return "错误";
        default: return "未知";
    }
}
#ifndef QUEUE_MODULE_H
#define QUEUE_MODULE_H

#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include "config.h"
#include "alert_type.h"
#include "pvdf_module.h"

struct AlertPacket {
    uint32_t timestamp;
    AlertType type;
    float body_temp;
    float env_temp;
    float env_humi;
    char detail[64];
    uint32_t audioId;
};

class QueueModule {
private:
    QueueHandle_t pvdfQueue;
    QueueHandle_t alertQueue;

public:
    QueueModule();
    bool begin();
    bool sendPVDF(const PVDFPacket& packet);
    bool receivePVDF(PVDFPacket& packet, TickType_t timeout = 0);
    bool sendAlert(AlertType type, const char* detail, float bodyTemp, float envTemp, float envHumi);
    bool sendAlertWithAudio(AlertType type, const char* detail, float bodyTemp, float envTemp, float envHumi, uint32_t audioId);
    bool receiveAlert(AlertPacket& packet, TickType_t timeout = 0);
    UBaseType_t getPVDFQueueSpace();
    UBaseType_t getAlertQueueSpace();
    UBaseType_t getPVDFQueueCount();
    UBaseType_t getAlertQueueCount();
};

#endif
#include "sleep_module.h"

SleepModule::SleepModule() : wakeupReason(WAKEUP_UNKNOWN) {}

void SleepModule::begin() {
    esp_sleep_enable_ext0_wakeup((gpio_num_t)WAKEUP_PIN, WAKEUP_LEVEL);
    checkWakeup();
}

WakeupReason SleepModule::checkWakeup() {
    esp_sleep_wakeup_cause_t cause = esp_sleep_get_wakeup_cause();
    switch (cause) {
        case ESP_SLEEP_WAKEUP_EXT0:
            wakeupReason = WAKEUP_PVDF;
            break;
        case ESP_SLEEP_WAKEUP_TIMER:
            wakeupReason = WAKEUP_TIMER;
            break;
        case ESP_SLEEP_WAKEUP_GPIO:
            wakeupReason = WAKEUP_GPIO;
            break;
        case ESP_SLEEP_WAKEUP_UNDEFINED:
            wakeupReason = WAKEUP_POWERON;
            break;
        default:
            wakeupReason = WAKEUP_UNKNOWN;
    }
    return wakeupReason;
}

void SleepModule::prepareSleep() {
    Serial.println("准备进入睡眠...");
    delay(DEEP_SLEEP_DELAY);
}

void SleepModule::enterDeepSleep() {
    Serial.println("进入深度睡眠");
    esp_deep_sleep_start();
}

void SleepModule::enterLightSleep(uint32_t sleepTimeMs) {
    if (sleepTimeMs > 0) {
        esp_sleep_enable_timer_wakeup(sleepTimeMs * 1000);
    }
    esp_light_sleep_start();
}

const char* SleepModule::reasonToString(WakeupReason reason) {
    switch (reason) {
        case WAKEUP_PVDF: return "PVDF 唤醒";
        case WAKEUP_TIMER: return "定时器唤醒";
        case WAKEUP_GPIO: return "GPIO 唤醒";
        case WAKEUP_POWERON: return "上电启动";
        default: return "未知";
    }
}
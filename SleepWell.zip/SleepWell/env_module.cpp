#include "env_module.h"

EnvModule::EnvModule()
    : lastTemp(25.0), lastHumi(50.0),
      tempState(ENV_TEMP_NORMAL), humiState(ENV_HUMI_NORMAL), sensorValid(false) {}

bool EnvModule::begin(TwoWire* i2cBus) {
    wire = i2cBus;
    for (int i = 0; i < 3; i++) {
        if (aht20.begin(wire)) {
            sensorValid = true;
            return true;
        }
        delay(100);
    }
    sensorValid = false;
    return false;
}

bool EnvModule::read(float& temp, float& humi) {
    if (!sensorValid) {
        temp = lastTemp;
        humi = lastHumi;
        return false;
    }
    sensors_event_t humidity, temperature;
    if (aht20.getEvent(&humidity, &temperature)) {
        lastTemp = temperature.temperature;
        lastHumi = humidity.relative_humidity;
    }
    temp = lastTemp;
    humi = lastHumi;
    return true;
}

EnvTempState EnvModule::checkTempState(float temp) {
    if (temp < ENV_TEMP_MIN - ENV_TEMP_HYST) {
        return ENV_TEMP_LOW;
    } else if (temp > ENV_TEMP_MAX + ENV_TEMP_HYST) {
        return ENV_TEMP_HIGH;
    } else if (temp >= ENV_TEMP_MIN && temp <= ENV_TEMP_MAX) {
        return ENV_TEMP_NORMAL;
    }
    return tempState;
}

EnvHumiState EnvModule::checkHumiState(float humi) {
    if (humi < ENV_HUMI_MIN - ENV_HUMI_HYST) {
        return ENV_HUMI_LOW;
    } else if (humi > ENV_HUMI_MAX + ENV_HUMI_HYST) {
        return ENV_HUMI_HIGH;
    } else if (humi >= ENV_HUMI_MIN && humi <= ENV_HUMI_MAX) {
        return ENV_HUMI_NORMAL;
    }
    return humiState;
}

bool EnvModule::readWithState(float& temp, float& humi, EnvTempState& tState, EnvHumiState& hState) {
    bool success = read(temp, humi);
    tempState = checkTempState(temp);
    humiState = checkHumiState(humi);
    tState = tempState;
    hState = humiState;
    return success;
}

const char* EnvModule::tempStateToString(EnvTempState state) {
    switch (state) {
        case ENV_TEMP_NORMAL: return "正常";
        case ENV_TEMP_LOW: return "低温";
        case ENV_TEMP_HIGH: return "高温";
        default: return "未知";
    }
}

const char* EnvModule::humiStateToString(EnvHumiState state) {
    switch (state) {
        case ENV_HUMI_NORMAL: return "正常";
        case ENV_HUMI_LOW: return "干燥";
        case ENV_HUMI_HIGH: return "潮湿";
        default: return "未知";
    }
}
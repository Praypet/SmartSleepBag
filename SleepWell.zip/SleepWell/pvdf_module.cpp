#include "pvdf_module.h"

static PVDFModule* pvdfInstance = nullptr;

PVDFModule::PVDFModule() : writeIndex(0), packetReady(false), timer(nullptr) {
    memset(buffer, 0, sizeof(buffer));
    pvdfInstance = this;
}

PVDFModule::~PVDFModule() {
    stop();
    pvdfInstance = nullptr;
}

void PVDFModule::initADC() {
    adc1_config_width(PVDF_ADC_WIDTH);
    adc1_config_channel_atten(PVDF_ADC_CHANNEL, PVDF_ADC_ATTEN);
}

void IRAM_ATTR PVDFModule::onTimer() {
    if (pvdfInstance) {
        uint16_t adc_val = adc1_get_raw(PVDF_ADC_CHANNEL);
        pvdfInstance->buffer[pvdfInstance->writeIndex] = adc_val;
        pvdfInstance->writeIndex = (pvdfInstance->writeIndex + 1) % PVDF_BUFFER_SIZE;
        if (pvdfInstance->writeIndex % PVDF_POINTS_PER_PACK == 0) {
            pvdfInstance->packetReady = true;
        }
    }
}

bool PVDFModule::begin() {
    initADC();
    return true;
}

void PVDFModule::start() {
    if (timer == nullptr) {
        timer = timerBegin(1000000);
        if (timer) {
            timerAttachInterrupt(timer, &onTimer);
            timerAlarm(timer, 50000, true, 0);
        }
    }
}

void PVDFModule::stop() {
    if (timer != nullptr) {
        timerEnd(timer);
        timer = nullptr;
    }
}

bool PVDFModule::isPacketReady() {
    return packetReady;
}

bool PVDFModule::getPacket(PVDFPacket& packet, float bodyTemp, float envTemp, float envHumi) {
    if (!packetReady) return false;
    
    packet.timestamp = millis();
    int startIdx = (writeIndex - PVDF_POINTS_PER_PACK + PVDF_BUFFER_SIZE) % PVDF_BUFFER_SIZE;
    
    for (int i = 0; i < PVDF_POINTS_PER_PACK; i++) {
        int idx = (startIdx + i) % PVDF_BUFFER_SIZE;
        packet.points[i] = buffer[idx];
    }
    
    packet.body_temp = bodyTemp;
    packet.env_temp = envTemp;
    packet.env_humi = envHumi;
    packet.temp_realtime = true;
    packet.env_realtime = true;
    packetReady = false;
    return true;
}

uint16_t PVDFModule::getValue(int index) {
    if (index >= 0 && index < PVDF_BUFFER_SIZE) {
        return buffer[index];
    }
    return 0;
}

uint16_t PVDFModule::getLatestValue() {
    int idx = (writeIndex - 1 + PVDF_BUFFER_SIZE) % PVDF_BUFFER_SIZE;
    return buffer[idx];
}

bool PVDFModule::isSignalValid() {
    static uint32_t lastCheck = 0;
    if (millis() - lastCheck < 1000) return true;
    lastCheck = millis();
    
    long sum = 0;
    for (int i = 0; i < 100; i++) {
        int idx = (writeIndex - 100 + i + PVDF_BUFFER_SIZE) % PVDF_BUFFER_SIZE;
        sum += buffer[idx];
    }
    int avg = sum / 100;
    
    long variance = 0;
    for (int i = 0; i < 100; i++) {
        int idx = (writeIndex - 100 + i + PVDF_BUFFER_SIZE) % PVDF_BUFFER_SIZE;
        variance += abs(buffer[idx] - avg);
    }
    variance /= 100;
    
    int adc_avg = avg;
    bool in_range = (adc_avg > 400 && adc_avg < 2700);
    
    return (variance > PVDF_SIGNAL_VALID_THRESHOLD) && in_range;
}
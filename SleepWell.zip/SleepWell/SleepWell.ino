/*
* 智能婴儿睡袋系统 - 主程序
* 版本: 1.0.1
* 硬件: ESP32-S3-N16R8
*/
#include "config.h"
#include "alert_type.h"
#include "audio_config.h"
#include "pvdf_module.h"
#include "temp_module.h"
#include "env_module.h"
#include "audio_module.h"
#include "wifi_module.h"
#include "sleep_module.h"
#include "queue_module.h"
#include "state_module.h"
#include "esp_task_wdt.h"

// ==================== 全局对象 ====================
TwoWire I2C_0 = TwoWire(0);
PVDFModule pvdf;
TempModule tempSensor;
EnvModule envSensor;
AudioModule audio;
WiFiModule wifi;
SleepModule sleepMgr;
QueueModule queue;
StateModule state;

// ==================== 全局变量 ====================
float lastBodyTemp = 37.0;
float lastEnvTemp = 25.0;
float lastEnvHumi = 50.0;

// ==================== 函数声明 ====================
void printSystemInfo();
void handleWakeup();
void handleAlerts();
void enterSleepIfNeeded();
void checkSensorHealth();

// ==================== setup() ====================
void setup() {
    Serial.begin(115200);
    delay(1000);
    printSystemInfo();
    
    // 先初始化看门狗（现在没有阻塞操作了）
    esp_task_wdt_config_t wdt_config = {
        .timeout_ms = 10000,
        .trigger_panic = true
    };
    esp_task_wdt_init(&wdt_config);
    esp_task_wdt_add(NULL);
    Serial.println("看门狗已启用，超时10秒");
    
    sleepMgr.begin();
    WakeupReason wakeReason = sleepMgr.getWakeupReason();
    Serial.printf("唤醒原因: %s\n", SleepModule::reasonToString(wakeReason));
    
    if (wakeReason != WAKEUP_POWERON) {
        handleWakeup();
    }
    
    I2C_0.begin(PIN_I2C_SDA, PIN_I2C_SCL, I2C_CLOCK_SPEED);
    Serial.println("初始化模块...");
    pvdf.begin();
    tempSensor.begin(&I2C_0);
    envSensor.begin(&I2C_0);
    audio.begin();
    queue.begin();
    state.begin();
    
    pvdf.start();
    wifi.begin();
    wifi.connect();  // 非阻塞，立即返回
    state.resetLeaveTimer();
    
    Serial.println("系统初始化完成，进入主循环");
    Serial.println("=====================\n");
}
// ==================== loop() ====================
void loop() {
    uint32_t loopStart = millis();
    static uint32_t lastSensorRead = 0;
    static uint32_t lastHealthCheck = 0;
    uint32_t now = millis();
    
    // 1. WiFi 维护
    wifi.loop();
    
    // 2. 处理音频录制（非阻塞 - 关键！）
    audio.processRecording();
    
    // 3. 传感器读取
    uint32_t interval = state.getCurrentInterval();
    if (now - lastSensorRead >= interval) {
        lastBodyTemp = tempSensor.read();
        BodyTempState tempState = tempSensor.updateState(lastBodyTemp);
        
        float envTemp, envHumi;
        EnvTempState envTempState;
        EnvHumiState envHumiState;
        envSensor.readWithState(envTemp, envHumi, envTempState, envHumiState);
        lastEnvTemp = envTemp;
        lastEnvHumi = envHumi;
        
        state.updateTempState(tempState, lastBodyTemp);
        state.updateEnvState(envTempState, envHumiState, lastEnvTemp, lastEnvHumi);
        
        AlertType alertType;
        char alertDetail[64];
        if (state.checkForAlert(alertType, alertDetail, sizeof(alertDetail))) {
            queue.sendAlert(alertType, alertDetail, lastBodyTemp, lastEnvTemp, lastEnvHumi);
        }
        
        Serial.printf("传感器 - 体温:%.1fC 环境:%.1fC %.0f%%\n",
            lastBodyTemp, lastEnvTemp, lastEnvHumi);
        
        lastSensorRead = now;
    }
    
    // 4. 处理 PVDF 数据包
    if (pvdf.isPacketReady()) {
        PVDFPacket packet;
        if (pvdf.getPacket(packet, lastBodyTemp, lastEnvTemp, lastEnvHumi)) {
            if (!queue.sendPVDF(packet)) {
                Serial.println("PVDF 队列已满");
            }
        }
        state.updateSignalValid(pvdf.isSignalValid());
    }
    
    // 5. 检测哭声（添加防抖机制）
    static uint32_t lastCryDetection = 0;
    const uint32_t CRY_DETECTION_COOLDOWN = 5000; // 5秒冷却时间

    if (audio.detectCry()) {
        uint32_t currentTime = millis();
        if (currentTime - lastCryDetection > CRY_DETECTION_COOLDOWN) {
            Serial.println("检测到婴儿哭声!");
            queue.sendAlert(ALERT_CRY, "检测到婴儿哭声", lastBodyTemp, lastEnvTemp, lastEnvHumi);
            audio.startRecording(ALERT_CRY, "哭声");
            lastCryDetection = currentTime;
        } else {
            Serial.println("哭声检测在冷却期内，忽略");
        }
        audio.resetCryState();
    }
    
    // 6. 检查婴儿是否离开（改为非阻塞启动）
    if (state.isBabyLeaving()) {
        Serial.println("婴儿已离开睡袋");
        queue.sendAlert(ALERT_LEAVE, "婴儿已离开睡袋", lastBodyTemp, lastEnvTemp, lastEnvHumi);
        audio.startRecording(ALERT_LEAVE, "婴儿离开");  // 改这里
        delay(2000);
        enterSleepIfNeeded();
    }
    
    // 7. 上传数据
    if (now - wifi.getLastUploadTime() >= UPLOAD_INTERVAL) {
        if (wifi.isConnected()) {
            state.setMainState(SYS_UPLOADING);
            wifi.uploadAlerts(queue);
            if (queue.getAlertQueueCount() == 0) {
                wifi.uploadAudio(audio);
            }
            wifi.uploadPVDF(queue);
            wifi.updateLastUploadTime();
            state.setMainState(state.getMainState());
        }
    }
    
    // 8. 定期清理已上传的音频
    static uint32_t lastCleanup = 0;
    if (now - lastCleanup > 300000) {
        audio.printPoolStatus();
        lastCleanup = now;
    }
    
    // 9. 定期检查传感器健康状态
    if (now - lastHealthCheck > 60000) {
        checkSensorHealth();
        lastHealthCheck = now;
    }
    
    // 10. 处理预警
    handleAlerts();
    
    // 11. 喂狗
    if (millis() - loopStart < 9000) {
        esp_task_wdt_reset();
    } else {
        Serial.println("警告: loop 执行时间过长! ");
    }
    
    delay(10);
}

// ==================== 辅助函数 ====================
void printSystemInfo() {
    Serial.println("\n====================================");
    Serial.println(" 智能婴儿睡袋系统 v" FIRMWARE_VERSION);
    Serial.println("====================================");
    Serial.printf("编译时间: %s %s\n", __DATE__, __TIME__);
    Serial.printf("芯片: %s\n", ESP.getChipModel());
    Serial.printf("Flash: %uMB\n", ESP.getFlashChipSize() / (1024 * 1024));
    Serial.printf("PSRAM: %s\n", ESP.getPsramSize() ? "可用" : "不可用");
    Serial.println("------------------------------------\n");
}

void handleWakeup() {
    Serial.println("处理唤醒事件...");
    if (sleepMgr.getWakeupReason() == WAKEUP_PVDF) {
        adc1_config_width(PVDF_ADC_WIDTH);
        adc1_config_channel_atten(PVDF_ADC_CHANNEL, PVDF_ADC_ATTEN);
    }
}

void handleAlerts() {
    if (queue.getAlertQueueCount() > 0 && wifi.isConnected()) {
        wifi.uploadData(queue);
    }
}

void checkSensorHealth() {
    static int validCount = 0, totalCount = 0;

    if (!tempSensor.isValid()) {
        queue.sendAlert(ALERT_SENSOR_FAULT, "体温传感器故障", lastBodyTemp, lastEnvTemp, lastEnvHumi);
    }
    if (!envSensor.isValid()) {
        queue.sendAlert(ALERT_SENSOR_FAULT, "环境传感器故障", lastBodyTemp, lastEnvTemp, lastEnvHumi);
    }

    totalCount++;
    if (pvdf.isSignalValid()) {
        validCount++;
    }
    if (totalCount >= 10) {
        float validRatio = (float)validCount / totalCount;
        if (validRatio < 0.1) {
            queue.sendAlert(ALERT_SENSOR_FAULT, "PVDF 信号异常", lastBodyTemp, lastEnvTemp, lastEnvHumi);
        }
        validCount = 0;
        totalCount = 0;
    }
}

void enterSleepIfNeeded() {
    pvdf.stop();
    audio.stop();
    if (wifi.isConnected()) {
        wifi.flushAll(queue, audio);
    }
    audio.printPoolStatus();
    sleepMgr.prepareSleep();
    sleepMgr.enterDeepSleep();
}
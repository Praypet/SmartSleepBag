#ifndef STATE_MODULE_H
#define STATE_MODULE_H

#include <Arduino.h>
#include "config.h"
#include "temp_module.h"
#include "env_module.h"
#include "alert_type.h"

enum SystemMainState {
    SYS_DEEP_SLEEP = 0,
    SYS_NORMAL,
    SYS_ABNORMAL,
    SYS_CRITICAL,
    SYS_UPLOADING
};

class StateModule {
private:
    SystemMainState mainState;
    BodyTempState tempState;
    float lastBodyTemp;
    EnvTempState envTempState;
    EnvHumiState envHumiState;
    float lastEnvTemp;
    float lastEnvHumi;
    uint32_t lastValidSignalTime;
    void updateMainState();

public:
    StateModule();
    void begin();
    void updateTempState(BodyTempState state, float value);
    void updateEnvState(EnvTempState tState, EnvHumiState hState, float temp, float humi);
    void updateSignalValid(bool valid);
    SystemMainState getMainState();
    uint32_t getCurrentInterval();
    bool checkForAlert(AlertType& type, char* detail, size_t detailSize);
    bool isBabyLeaving();
    void resetLeaveTimer() { lastValidSignalTime = millis(); }
    BodyTempState getTempState() { return tempState; }
    void setMainState(SystemMainState state) { mainState = state; }
    static const char* mainStateToString(SystemMainState state);
};

#endif
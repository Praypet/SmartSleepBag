#ifndef ENV_MODULE_H
#define ENV_MODULE_H

#include <Arduino.h>
#include <Adafruit_AHTX0.h>
#include <Wire.h>
#include "config.h"

enum EnvTempState {
    ENV_TEMP_NORMAL = 0,
    ENV_TEMP_LOW,
    ENV_TEMP_HIGH
};

enum EnvHumiState {
    ENV_HUMI_NORMAL = 0,
    ENV_HUMI_LOW,
    ENV_HUMI_HIGH
};

class EnvModule {
private:
    Adafruit_AHTX0 aht20;
    TwoWire* wire;
    float lastTemp;
    float lastHumi;
    EnvTempState tempState;
    EnvHumiState humiState;
    bool sensorValid;
    
    EnvTempState checkTempState(float temp);
    EnvHumiState checkHumiState(float humi);

public:
    EnvModule();
    bool begin(TwoWire* i2cBus);
    bool read(float& temp, float& humi);
    bool readWithState(float& temp, float& humi, EnvTempState& tState, EnvHumiState& hState);
    float getLastTemp() { return lastTemp; }
    float getLastHumi() { return lastHumi; }
    EnvTempState getTempState() { return tempState; }
    EnvHumiState getHumiState() { return humiState; }
    bool isValid() { return sensorValid; }
    static const char* tempStateToString(EnvTempState state);
    static const char* humiStateToString(EnvHumiState state);
};

#endif
#ifndef AUDIO_MODULE_H
#define AUDIO_MODULE_H

#include <Arduino.h>
#include <driver/i2s.h>
#include "audio_config.h"
#include "alert_type.h"

// 音频录制完成回调函数类型
typedef void (*AudioRecordedCallback)(uint32_t audioId, AlertType relatedAlert);

class AudioModule {
private:
    // I2S 相关
    bool initialized;
    i2s_config_t i2sConfig;
    i2s_pin_config_t pinConfig;
    
    // 哭声检测相关
    bool isCrying;
    uint32_t cryingStartTime;
    uint16_t cryThreshold;
    
    // 音频池管理
    AudioSegment audioPool[AUDIO_POOL_SIZE];
    uint32_t nextAudioId;
    SemaphoreHandle_t poolMutex;
    
    // 录制状态
    bool isRecording;
    AudioSegment* currentRecording;
    uint32_t recordingStartTime;
    uint32_t recordingBytes;
    
    // 回调
    AudioRecordedCallback recordedCallback;
    
    // 私有方法
    uint16_t calculateEnergy(const int16_t* samples, size_t count);
    int findFreeSegmentIndex();
    AudioSegment* getNextUploadSegment();
    bool generateWavHeader(AudioSegment* segment);
    void cleanupUploadedSegments();
    bool initI2S();
    
    // ========== 新增：非阻塞录制相关 ==========
    enum RecordingState {
        RECORD_IDLE,
        RECORD_STARTING,
        RECORDING,
        RECORD_FINISHING
    };
    RecordingState recState;
    uint8_t* recordingBuffer;
    uint32_t recordingBufferSize;
    uint32_t recordingTargetBytes;
    uint32_t recordingNonBlockBytes;
    uint32_t recordingNonBlockStartTime;
    AlertType recordingAlertType;
    char recordingDescription[64];
    AudioSegment* currentRecordingSegment;

public:
    AudioModule();
    ~AudioModule();
    
    bool begin();
    void stop();
    void setCryThreshold(uint16_t threshold) { cryThreshold = threshold; }
    
    bool detectCry();
    void resetCryState() { isCrying = false; }
    
    // 同步录制（兼容旧代码）
    uint32_t recordAudio(AlertType relatedAlert = ALERT_NONE, const char* description = "audio");
    
    // 非阻塞录制（新方法）
    bool startRecording(AlertType relatedAlert = ALERT_NONE, const char* description = "audio");
    void processRecording();
    
    bool hasAudioToUpload();
    bool getAudioForUpload(uint8_t*& data, uint32_t& size, uint32_t& audioId, uint8_t& priority);
    void markAudioUploaded(uint32_t audioId, bool success);
    
    uint32_t getFreeSegments();
    uint32_t getReadySegments();
    void onAudioRecorded(AudioRecordedCallback callback) { recordedCallback = callback; }
    void printPoolStatus();
};

#endif
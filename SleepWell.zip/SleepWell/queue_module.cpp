#include "queue_module.h"

QueueModule::QueueModule() : pvdfQueue(NULL), alertQueue(NULL) {}

bool QueueModule::begin() {
    pvdfQueue = xQueueCreate(QUEUE_SIZE, sizeof(PVDFPacket));
    alertQueue = xQueueCreate(QUEUE_SIZE, sizeof(AlertPacket));
    return (pvdfQueue != NULL && alertQueue != NULL);
}

bool QueueModule::sendPVDF(const PVDFPacket& packet) {
    if (pvdfQueue == NULL) return false;
    return xQueueSend(pvdfQueue, &packet, 0) == pdTRUE;
}

bool QueueModule::receivePVDF(PVDFPacket& packet, TickType_t timeout) {
    if (pvdfQueue == NULL) return false;
    return xQueueReceive(pvdfQueue, &packet, timeout) == pdTRUE;
}

bool QueueModule::sendAlert(AlertType type, const char* detail, float bodyTemp, float envTemp, float envHumi) {
    return sendAlertWithAudio(type, detail, bodyTemp, envTemp, envHumi, 0);
}

bool QueueModule::sendAlertWithAudio(AlertType type, const char* detail, float bodyTemp, float envTemp, float envHumi, uint32_t audioId) {
    if (alertQueue == NULL) return false;
    
    AlertPacket packet;
    packet.timestamp = millis();
    packet.type = type;
    packet.body_temp = bodyTemp;
    packet.env_temp = envTemp;
    packet.env_humi = envHumi;
    packet.audioId = audioId;
    strncpy(packet.detail, detail, sizeof(packet.detail) - 1);
    packet.detail[sizeof(packet.detail) - 1] = '\0';
    
    return xQueueSendToFront(alertQueue, &packet, 0) == pdTRUE;
}

bool QueueModule::receiveAlert(AlertPacket& packet, TickType_t timeout) {
    if (alertQueue == NULL) return false;
    return xQueueReceive(alertQueue, &packet, timeout) == pdTRUE;
}

UBaseType_t QueueModule::getPVDFQueueSpace() {
    if (pvdfQueue == NULL) return 0;
    return uxQueueSpacesAvailable(pvdfQueue);
}

UBaseType_t QueueModule::getAlertQueueSpace() {
    if (alertQueue == NULL) return 0;
    return uxQueueSpacesAvailable(alertQueue);
}

UBaseType_t QueueModule::getPVDFQueueCount() {
    if (pvdfQueue == NULL) return 0;
    return uxQueueMessagesWaiting(pvdfQueue);
}

UBaseType_t QueueModule::getAlertQueueCount() {
    if (alertQueue == NULL) return 0;
    return uxQueueMessagesWaiting(alertQueue);
}
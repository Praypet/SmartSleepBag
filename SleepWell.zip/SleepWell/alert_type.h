#ifndef ALERT_TYPE_H
#define ALERT_TYPE_H

enum AlertType {
    ALERT_NONE = 0,
    ALERT_TEMP_ABNORMAL,
    ALERT_ENV_ABNORMAL,
    ALERT_CRY,
    ALERT_LEAVE,
    ALERT_SENSOR_FAULT
};

#endif
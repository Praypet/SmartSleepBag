#include "temp_module.h"

TempModule::TempModule() : lastValue(37.0), currentState(TEMP_NORMAL), sensorValid(false), wire(nullptr) {}

bool TempModule::begin(TwoWire* i2cBus) {
    wire = i2cBus;
    for (int i = 0; i < 3; i++) {
        if (tmp117.begin(0x48, wire)) {
            sensorValid = true;
            return true;
        }
        delay(100);
    }
    sensorValid = false;
    return false;
}

float TempModule::read() {
    if (!sensorValid) return lastValue;
    sensors_event_t temp_event;
    if (tmp117.getEvent(&temp_event)) {
        lastValue = temp_event.temperature;
    }
    return lastValue;
}

BodyTempState TempModule::checkState(float temp) {
    if (temp < TEMP_CRITICAL_LOW) {
        return TEMP_LOW_CRITICAL;
    } else if (temp > TEMP_CRITICAL_HIGH) {
        return TEMP_HIGH_CRITICAL;
    } else if (temp < TEMP_NORMAL_MIN - TEMP_HYSTERESIS) {
        return TEMP_LOW_ABNORMAL;
    } else if (temp > TEMP_NORMAL_MAX + TEMP_HYSTERESIS) {
        return TEMP_HIGH_ABNORMAL;
    } else if (temp >= TEMP_NORMAL_MIN && temp <= TEMP_NORMAL_MAX) {
        return TEMP_NORMAL;
    }
    return currentState;
}

BodyTempState TempModule::updateState(float newValue) {
    BodyTempState newState = checkState(newValue);
    if (newState != currentState) {
        currentState = newState;
    }
    return currentState;
}

const char* TempModule::stateToString(BodyTempState state) {
    switch (state) {
        case TEMP_NORMAL: return "正常";
        case TEMP_LOW_ABNORMAL: return "低温异常";
        case TEMP_HIGH_ABNORMAL: return "高温异常";
        case TEMP_LOW_CRITICAL: return "低温危急";
        case TEMP_HIGH_CRITICAL: return "高温危急";
        default: return "未知";
    }
}
#ifndef TEMP_MODULE_H
#define TEMP_MODULE_H

#include <Arduino.h>
#include <Adafruit_TMP117.h>
#include <Wire.h>
#include "config.h"

enum BodyTempState {
    TEMP_NORMAL = 0,
    TEMP_LOW_ABNORMAL,
    TEMP_HIGH_ABNORMAL,
    TEMP_LOW_CRITICAL,
    TEMP_HIGH_CRITICAL
};

class TempModule {
private:
    Adafruit_TMP117 tmp117;
    TwoWire* wire;
    float lastValue;
    BodyTempState currentState;
    bool sensorValid;
    
    BodyTempState checkState(float temp);

public:
    TempModule();
    bool begin(TwoWire* i2cBus);
    float read();
    float getLastValue() { return lastValue; }
    BodyTempState getState() { return currentState; }
    BodyTempState updateState(float newValue);
    bool isValid() { return sensorValid; }
    static const char* stateToString(BodyTempState state);
};

#endif
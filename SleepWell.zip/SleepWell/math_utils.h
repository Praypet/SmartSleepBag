/*滑动平均滤波器：平滑连续的传感器数据，降低随机噪声
中值滤波器：剔除突发的异常值（尖峰噪声），保留真实信号
注释掉的心率检测器：基于峰值检测的简易心率计算（未启用）*/

#ifndef MATH_UTILS_H
#define MATH_UTILS_H
#include <Arduino.h>

// 滑动平均滤波器:对连续输入的传感器数据（如温度、电压、加速度）进行平滑处理，削弱随机波动的噪声，保留趋势性变化。
class MovingAverageFilter {

private:
    float* buffer;    // 存储历史数据的缓冲区（动态数组）
    int size;         // 滤波器窗口大小（平均的点数，比如5、10）
    int index;        // 当前数据要写入的缓冲区索引（循环覆盖）
    float sum;        // 缓冲区中所有数据的总和（缓存值，避免重复计算）
    bool filled;      // 标记缓冲区是否被填满（未满时用实际点数计算平均）

public:
    MovingAverageFilter(int n) : size(n), index(0), sum(0), filled(false) {
        buffer = new float[size];
        memset(buffer, 0, sizeof(float) * size);
    }
    ~MovingAverageFilter() {
        delete[] buffer;
    }
    
    float filter(float value) {
        sum -= buffer[index];
        buffer[index] = value;
        sum += value;
        index = (index + 1) % size;
        if (!filled && index == 0) {
            filled = true;
        }
        int count = filled ? size : index;
        return sum / count;
    }
    void reset() {
        memset(buffer, 0, sizeof(float) * size);
        index = 0;
        sum = 0;
        filled = false;
    }
};

// 中值滤波器
class MedianFilter {
    private:
    float* buffer;
    int size;
    int index;

public:
    MedianFilter(int n) : size(n), index(0) {
        buffer = new float[size];
        memset(buffer, 0, sizeof(float) * size);
    } 
    ~MedianFilter() {
        delete[] buffer;
    }
    float filter(float value) {
        buffer[index] = value;
        index = (index + 1) % size;
        // 复制并排序
        float temp[size];
        memcpy(temp, buffer, sizeof(float) * size);
        // 简单冒泡排序（n 很小）
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                if (temp[j] > temp[j + 1]) {
                    float t = temp[j];
                    temp[j] = temp[j + 1];
                    temp[j + 1] = t;
                  }
                }
            }
        return temp[size / 2];
    }
};
/*
// 心率计算（简易版）
class HeartRateDetector {
private:
    float threshold;
    uint32_t lastPeakTime;
    int32_t lastBeatInterval;
    float currentRate;

public:
    HeartRateDetector() : threshold(0.5), lastPeakTime(0), lastBeatInterval(0), currentRate(0) {}
    float process(float value, uint32_t timestamp) {
        // 简单峰值检测
        if (value > threshold && (timestamp - lastPeakTime) > 300) { // 300ms 防抖
            if (lastPeakTime > 0) {
                uint32_t interval = timestamp - lastPeakTime;
                // 心率 = 60000 / 间隔(ms)
                currentRate = 60000.0 / interval;
                lastBeatInterval = interval;
            }
            lastPeakTime = timestamp;
        }
        return currentRate;
    }
    void setThreshold(float t) { threshold = t; }
    float getRate() { return currentRate; }
}; */
#endif
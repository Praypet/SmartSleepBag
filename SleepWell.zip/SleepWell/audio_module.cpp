#include "audio_module.h"
#include "esp_heap_caps.h"

AudioModule::AudioModule()
    : initialized(false),
      isCrying(false),
      cryingStartTime(0),
      cryThreshold(CRY_THRESHOLD),
      nextAudioId(1),
      isRecording(false),
      currentRecording(nullptr),
      recordingStartTime(0),
      recordingBytes(0),
      recordedCallback(nullptr),
      recState(RECORD_IDLE),
      recordingBuffer(nullptr),
      recordingBufferSize(0),
      recordingTargetBytes(0),
      recordingNonBlockBytes(0),
      recordingNonBlockStartTime(0),
      currentRecordingSegment(nullptr)
{
    memset(audioPool, 0, sizeof(audioPool));
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        audioPool[i].state = AUDIO_STATE_EMPTY;
        audioPool[i].data = nullptr;
    }
    poolMutex = xSemaphoreCreateMutex();
}

AudioModule::~AudioModule() {
    stop();
    if (poolMutex) {
        xSemaphoreTake(poolMutex, portMAX_DELAY);
        for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
            if (audioPool[i].data) {
                free(audioPool[i].data);
                audioPool[i].data = nullptr;
            }
        }
        xSemaphoreGive(poolMutex);
        vSemaphoreDelete(poolMutex);
    }
}

bool AudioModule::initI2S() {
    i2sConfig = {
        .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
        .sample_rate = AUDIO_SAMPLE_RATE,
        .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
        .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
        .communication_format = I2S_COMM_FORMAT_STAND_I2S,
        .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
        .dma_buf_count = 8,
        .dma_buf_len = AUDIO_CHUNK_SIZE / 2,
        .use_apll = false
    };
    
    pinConfig = {
        .bck_io_num = PIN_I2S_BCK,
        .ws_io_num = PIN_I2S_WS,
        .data_out_num = I2S_PIN_NO_CHANGE,
        .data_in_num = PIN_I2S_DOUT
    };
    
    esp_err_t err = i2s_driver_install(I2S_NUM_0, &i2sConfig, 0, NULL);
    if (err != ESP_OK) {
        Serial.printf("I2S 驱动安装失败: %d\n", err);
        return false;
    }
    
    err = i2s_set_pin(I2S_NUM_0, &pinConfig);
    if (err != ESP_OK) {
        Serial.printf("I2S 引脚配置失败: %d\n", err);
        i2s_driver_uninstall(I2S_NUM_0);
        return false;
    }
    
    return true;
}

bool AudioModule::begin() {
    if (initI2S()) {
        initialized = true;
        Serial.println("音频模块初始化成功, PSRAM 音频池大小: " + String(AUDIO_POOL_TOTAL_SIZE / 1024) + "KB");
        return true;
    }
    return false;
}

void AudioModule::stop() {
    if (initialized) {
        if (isRecording) {
            isRecording = false;
            if (currentRecording) {
                currentRecording->state = AUDIO_STATE_READY;
            }
        }
        i2s_driver_uninstall(I2S_NUM_0);
        initialized = false;
    }
}

uint16_t AudioModule::calculateEnergy(const int16_t* samples, size_t count) {
    int32_t sum = 0;
    for (size_t i = 0; i < count; i++) {
        sum += abs(samples[i]);
    }
    return (count > 0) ? (sum / count) : 0;
}

bool AudioModule::detectCry() {
    if (!initialized) return false;
    
    uint8_t buffer[AUDIO_CHUNK_SIZE];
    size_t bytesRead = 0;
    esp_err_t err = i2s_read(I2S_NUM_0, buffer, AUDIO_CHUNK_SIZE, &bytesRead, 0);
    
    if (err == ESP_OK && bytesRead > 0) {
        int16_t* samples = (int16_t*)buffer;
        int sampleCount = bytesRead / 2;
        uint16_t energy = calculateEnergy(samples, sampleCount);
        
        // 添加多级判断，不仅看能量还要看变化模式
        static uint32_t consecutiveHighEnergyCount = 0;
        static uint32_t totalChecks = 0;
        static uint32_t cryStartTimestamp = 0;
        static bool isCurrentlyCrying = false;
        
        // 检查是否超过阈值
        if (energy > cryThreshold) {
            consecutiveHighEnergyCount++;
            totalChecks++;
            
            if (consecutiveHighEnergyCount == 1) {
                // 第一次检测到高能量
                cryStartTimestamp = millis();
            }
            
            // 需要连续多个周期都超过阈值
            if (consecutiveHighEnergyCount >= 3 && 
                (millis() - cryStartTimestamp) > CRY_DURATION && 
                !isCurrentlyCrying) {
                
                // 额外检查：确保能量值确实显著高于背景噪音
                static uint16_t backgroundLevel = 0;
                static bool initialBackgroundSet = false;
                
                if (!initialBackgroundSet) {
                    backgroundLevel = energy;
                    initialBackgroundSet = true;
                } else {
                    // 检查当前能量是否比背景噪音高很多
                    if (energy > (backgroundLevel * 3)) { // 至少3倍于背景噪音
                        isCurrentlyCrying = true;
                        consecutiveHighEnergyCount = 0;
                        totalChecks = 0;
                        
                        // 更新背景噪音水平
                        backgroundLevel = (backgroundLevel * 7 + energy) / 8;
                        
                        Serial.printf("确认婴儿哭声! 能量: %d, 背景: %d\n", energy, backgroundLevel);
                        return true;
                    }
                }
            }
        } else {
            // 重置计数器
            if (energy < cryThreshold * 0.5) { // 明显低于阈值时才重置
                consecutiveHighEnergyCount = 0;
                isCurrentlyCrying = false;
            }
            totalChecks++;
            
            // 慢慢更新背景噪音水平
            static uint16_t backgroundLevel = 0;
            if (totalChecks % 10 == 0) { // 每10次更新一次背景噪音
                backgroundLevel = (backgroundLevel * 9 + energy) / 10;
            }
        }
    }
    return false;
}

int AudioModule::findFreeSegmentIndex() {
    int selectedIndex = -1;
    uint32_t oldestTime = UINT32_MAX;
    
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        if (audioPool[i].state == AUDIO_STATE_EMPTY) {
            selectedIndex = i;
            break;
        } else if (audioPool[i].state == AUDIO_STATE_UPLOADED) {
            selectedIndex = i;
            break;
        } else if (audioPool[i].priority == AUDIO_PRIORITY_NORMAL) {
            if (audioPool[i].timestamp <= oldestTime) {
                oldestTime = audioPool[i].timestamp;
                selectedIndex = i;
            }
        }
    }
    
    if (selectedIndex >= 0 && audioPool[selectedIndex].data) {
        free(audioPool[selectedIndex].data);
        audioPool[selectedIndex].data = nullptr;
        audioPool[selectedIndex].state = AUDIO_STATE_EMPTY;
    }
    
    xSemaphoreGive(poolMutex);
    return selectedIndex;
}

bool AudioModule::generateWavHeader(AudioSegment* segment) {
    if (!segment || !segment->data) return false;
    
    typedef struct {
        char chunkID[4];
        uint32_t chunkSize;
        char format[4];
        char subchunk1ID[4];
        uint32_t subchunk1Size;
        uint16_t audioFormat;
        uint16_t numChannels;
        uint32_t sampleRate;
        uint32_t byteRate;
        uint16_t blockAlign;
        uint16_t bitsPerSample;
        char subchunk2ID[4];
        uint32_t subchunk2Size;
    } wav_header_t;
    
    wav_header_t header;
    memcpy(header.chunkID, "RIFF", 4);
    header.chunkSize = segment->size + sizeof(wav_header_t) - 8;
    memcpy(header.format, "WAVE", 4);
    memcpy(header.subchunk1ID, "fmt ", 4);
    header.subchunk1Size = 16;
    header.audioFormat = 1;
    header.numChannels = AUDIO_CHANNELS;
    header.sampleRate = AUDIO_SAMPLE_RATE;
    header.byteRate = AUDIO_SAMPLE_RATE * AUDIO_CHANNELS * AUDIO_BITS_PER_SAMPLE / 8;
    header.blockAlign = AUDIO_CHANNELS * AUDIO_BITS_PER_SAMPLE / 8;
    header.bitsPerSample = AUDIO_BITS_PER_SAMPLE;
    memcpy(header.subchunk2ID, "data", 4);
    header.subchunk2Size = segment->size;
    
    memmove(segment->data + sizeof(wav_header_t), segment->data, segment->size);
    memcpy(segment->data, &header, sizeof(wav_header_t));
    segment->size += sizeof(wav_header_t);
    
    return true;
}

// 非阻塞录制启动
bool AudioModule::startRecording(AlertType relatedAlert, const char* description) {
    if (!initialized || recState != RECORD_IDLE) {
        // 添加更多信息用于调试
        if (recState != RECORD_IDLE) {
            Serial.printf("录制被阻止：当前状态=%d\n", recState);
        }
        return false;
    }
    
    if (!initialized || recState != RECORD_IDLE) {
        Serial.println("无法录制：音频模块未就绪或已在录制中");
        return false;
    }
    
    int segmentIndex = findFreeSegmentIndex();
    if (segmentIndex < 0) {
        Serial.println("音频池已满，无法录制");
        return false;
    }
    
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    AudioSegment* segment = &audioPool[segmentIndex];
    
    uint32_t totalSize = AUDIO_10SEC_BYTES + AUDIO_WAV_HEADER_SIZE;
    
    uint8_t* buffer = nullptr;
    if (ESP.getPsramSize() > 0) {
        buffer = (uint8_t*)ps_malloc(totalSize);
        if (buffer) {
            Serial.printf("使用 PSRAM 分配音频内存: %dKB\n", totalSize / 1024);
        }
    }
    if (!buffer) {
        buffer = (uint8_t*)malloc(totalSize);
        if (buffer) {
            Serial.printf("使用内部 RAM 分配音频内存: %dKB\n", totalSize / 1024);
        }
    }
    
    if (!buffer) {
        Serial.println("严重错误：音频内存分配失败");
        xSemaphoreGive(poolMutex);
        return false;
    }
    
    segment->id = nextAudioId++;
    segment->timestamp = millis();
    segment->priority = (relatedAlert != ALERT_NONE) ? AUDIO_PRIORITY_ALERT : AUDIO_PRIORITY_NORMAL;
    if (relatedAlert == ALERT_CRY) {
        segment->priority = AUDIO_PRIORITY_CRY;
    }
    segment->state = AUDIO_STATE_RECORDING;
    segment->size = 0;
    segment->data = buffer;
    segment->relatedAlertId = (uint32_t)relatedAlert;
    strncpy(segment->description, description, sizeof(segment->description) - 1);
    segment->description[sizeof(segment->description) - 1] = '\0';
    
    xSemaphoreGive(poolMutex);
    
    recState = RECORD_STARTING;
    currentRecordingSegment = segment;
    recordingBuffer = buffer;
    recordingBufferSize = totalSize;
    recordingTargetBytes = AUDIO_10SEC_BYTES;
    recordingNonBlockBytes = 0;
    recordingNonBlockStartTime = millis();
    recordingAlertType = relatedAlert;
    strncpy(recordingDescription, description, 63);
    
    Serial.printf("开始录制音频 ID=%d, 优先级=%d\n", segment->id, segment->priority);
    
    return true;
}

// 处理录制（在loop中调用）
void AudioModule::processRecording() {
    if (recState == RECORD_IDLE) return;
    
    if (recState == RECORD_STARTING) {
        uint8_t dummy[1024];
        size_t bytesRead;
        for (int i = 0; i < 4; i++) {
            i2s_read(I2S_NUM_0, dummy, sizeof(dummy), &bytesRead, pdMS_TO_TICKS(10));
        }
        recState = RECORDING;
        recordingNonBlockStartTime = millis();
        return;
    }
    
    if (recState == RECORDING) {
        if (millis() - recordingNonBlockStartTime > AUDIO_RECORD_DURATION + 1000) {
            Serial.println("音频录制超时");
            recState = RECORD_FINISHING;
            return;
        }
        
        size_t bytesRead = 0;
        size_t remaining = recordingTargetBytes - recordingNonBlockBytes;
        size_t toRead = (remaining < AUDIO_CHUNK_SIZE) ? remaining : AUDIO_CHUNK_SIZE;
        
        if (toRead > 0) {
            esp_err_t err = i2s_read(I2S_NUM_0, 
                recordingBuffer + AUDIO_WAV_HEADER_SIZE + recordingNonBlockBytes,
                toRead, &bytesRead, pdMS_TO_TICKS(10));
            
            if (err == ESP_OK && bytesRead > 0) {
                recordingNonBlockBytes += bytesRead;
            }
        }
        
        if (recordingNonBlockBytes >= recordingTargetBytes) {
            recState = RECORD_FINISHING;
        }
        return;
    }
    
    if (recState == RECORD_FINISHING) {
        if (currentRecordingSegment) {
            currentRecordingSegment->size = recordingNonBlockBytes;
            generateWavHeader(currentRecordingSegment);
            currentRecordingSegment->state = AUDIO_STATE_READY;
            
            Serial.printf("音频录制完成 ID=%d, 大小=%d字节\n", 
                currentRecordingSegment->id, currentRecordingSegment->size);
            
            if (recordedCallback) {
                recordedCallback(currentRecordingSegment->id, (AlertType)currentRecordingSegment->relatedAlertId);
            }
        }
        
        currentRecordingSegment = nullptr;
        recordingBuffer = nullptr;
        recState = RECORD_IDLE;
    }
}

// 同步录制（兼容旧代码）
uint32_t AudioModule::recordAudio(AlertType relatedAlert, const char* description) {
    if (!startRecording(relatedAlert, description)) {
        return 0;
    }
    
    while (recState != RECORD_IDLE) {
        processRecording();
        delay(1);
    }
    
    return currentRecordingSegment ? currentRecordingSegment->id : 0;
}

bool AudioModule::hasAudioToUpload() {
    bool hasAudio = false;
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        if (audioPool[i].state == AUDIO_STATE_READY) {
            hasAudio = true;
            break;
        }
    }
    xSemaphoreGive(poolMutex);
    return hasAudio;
}

AudioSegment* AudioModule::getNextUploadSegment() {
    AudioSegment* selected = nullptr;
    int highestPriority = 999;
    
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        if (audioPool[i].state == AUDIO_STATE_READY) {
            if (audioPool[i].priority < highestPriority) {
                highestPriority = audioPool[i].priority;
                selected = &audioPool[i];
            }
        }
    }
    if (selected) {
        selected->state = AUDIO_STATE_UPLOADING;
    }
    xSemaphoreGive(poolMutex);
    return selected;
}

bool AudioModule::getAudioForUpload(uint8_t*& data, uint32_t& size, uint32_t& audioId, uint8_t& priority) {
    AudioSegment* segment = getNextUploadSegment();
    if (!segment) return false;
    
    data = segment->data;
    size = segment->size;
    audioId = segment->id;
    priority = segment->priority;
    return true;
}

void AudioModule::markAudioUploaded(uint32_t audioId, bool success) {
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        if (audioPool[i].id == audioId) {
            if (success) {
                audioPool[i].state = AUDIO_STATE_UPLOADED;
                Serial.printf("音频ID=%d上传成功\n", audioId);
            } else {
                audioPool[i].state = AUDIO_STATE_READY;
                Serial.printf("音频ID=%d上传失败，将重试\n", audioId);
            }
            break;
        }
    }
    xSemaphoreGive(poolMutex);
}

uint32_t AudioModule::getFreeSegments() {
    uint32_t count = 0;
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        if (audioPool[i].state == AUDIO_STATE_EMPTY || audioPool[i].state == AUDIO_STATE_UPLOADED) {
            count++;
        }
    }
    xSemaphoreGive(poolMutex);
    return count;
}

uint32_t AudioModule::getReadySegments() {
    uint32_t count = 0;
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        if (audioPool[i].state == AUDIO_STATE_READY) {
            count++;
        }
    }
    xSemaphoreGive(poolMutex);
    return count;
}

void AudioModule::cleanupUploadedSegments() {
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        if (audioPool[i].state == AUDIO_STATE_UPLOADED) {
            if (audioPool[i].data) {
                free(audioPool[i].data);
                audioPool[i].data = nullptr;
            }
            audioPool[i].state = AUDIO_STATE_EMPTY;
        }
    }
    xSemaphoreGive(poolMutex);
}

void AudioModule::printPoolStatus() {
    xSemaphoreTake(poolMutex, portMAX_DELAY);
    Serial.println("\n== 音频池状态 ==");
    for (int i = 0; i < AUDIO_POOL_SIZE; i++) {
        const char* stateStr = "未知";
        switch (audioPool[i].state) {
            case AUDIO_STATE_EMPTY: stateStr = "空闲"; break;
            case AUDIO_STATE_RECORDING: stateStr = "录制中"; break;
            case AUDIO_STATE_READY: stateStr = "就绪"; break;
            case AUDIO_STATE_UPLOADING: stateStr = "上传中"; break;
            case AUDIO_STATE_UPLOADED: stateStr = "已上传"; break;
        }
        Serial.printf("  [%d] ID=%d, 状态=%s, 优先级=%d, 大小=%d\n",
            i, audioPool[i].id, stateStr, audioPool[i].priority, audioPool[i].size);
    }
    Serial.println("================\n");
    xSemaphoreGive(poolMutex);
}
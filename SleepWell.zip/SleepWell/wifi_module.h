#ifndef WIFI_MODULE_H
#define WIFI_MODULE_H

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include "config.h"
#include "queue_module.h"

class AudioModule;
struct PVDFPacket;

enum WiFiState {
    WIFI_DISCONNECTED = 0,
    WIFI_CONNECTING,
    WIFI_CONNECTED,
    WIFI_ERROR
};

class WiFiModule {
private:
    WiFiState state;
    uint32_t lastConnectAttempt;
    uint32_t lastUploadTime;
    uint32_t connectStartTime;  // 新增：记录连接开始时间
    WiFiClient wifiClient;
    
    // 上传函数...
    bool uploadAlert(const AlertPacket& alert);
    bool uploadPVDFBatch(PVDFPacket* packets, int count);
    bool uploadAudioSegment(uint32_t audioId, const uint8_t* data, uint32_t size, uint8_t priority);
    
public:
    WiFiModule();
    void begin();
    void loop();
    bool connect();      // 改为非阻塞启动连接
    void disconnect();
    bool isConnected() { return state == WIFI_CONNECTED; }
    WiFiState getState() { return state; }
    uint32_t getLastUploadTime() { return lastUploadTime; }
    void updateLastUploadTime() { lastUploadTime = millis(); }
    
    // 上传函数...
    bool uploadAlerts(QueueModule& queue);
    bool uploadAudio(AudioModule& audio);
    bool uploadPVDF(QueueModule& queue);
    bool uploadData(QueueModule& queue);
    bool uploadData(QueueModule& queue, AudioModule& audio);
    void flushAll(QueueModule& queue, AudioModule& audio);
    
    static const char* stateToString(WiFiState state);
};

#endif
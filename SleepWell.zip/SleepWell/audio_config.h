#ifndef AUDIO_CONFIG_H
#define AUDIO_CONFIG_H

#include "config.h"
#include "alert_type.h"

#define AUDIO_SAMPLE_RATE 16000
#define AUDIO_BITS_PER_SAMPLE 16
#define AUDIO_CHANNELS 1
#define AUDIO_RECORD_DURATION 10000
#define AUDIO_CHUNK_SIZE 1024

#define AUDIO_BYTES_PER_SEC (AUDIO_SAMPLE_RATE * AUDIO_BITS_PER_SAMPLE / 8 * AUDIO_CHANNELS)
#define AUDIO_10SEC_BYTES (AUDIO_BYTES_PER_SEC * 10)
#define AUDIO_WAV_HEADER_SIZE 44

#define AUDIO_POOL_SIZE 6
#define AUDIO_POOL_TOTAL_SIZE (AUDIO_POOL_SIZE * (AUDIO_10SEC_BYTES + AUDIO_WAV_HEADER_SIZE))

#define AUDIO_PRIORITY_CRY 0
#define AUDIO_PRIORITY_ALERT 1
#define AUDIO_PRIORITY_NORMAL 2

enum AudioSegmentState {
    AUDIO_STATE_EMPTY = 0,
    AUDIO_STATE_RECORDING,
    AUDIO_STATE_READY,
    AUDIO_STATE_UPLOADING,
    AUDIO_STATE_UPLOADED
};

struct AudioSegment {
    uint32_t id;
    uint32_t timestamp;
    uint8_t priority;
    AudioSegmentState state;
    uint32_t size;
    uint8_t* data;
    uint32_t relatedAlertId;
    char description[32];
};

#endif
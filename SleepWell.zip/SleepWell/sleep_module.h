#ifndef SLEEP_MODULE_H
#define SLEEP_MODULE_H

#include <Arduino.h>
#include <esp_sleep.h>
#include "config.h"

enum WakeupReason {
    WAKEUP_PVDF = 0,
    WAKEUP_TIMER,
    WAKEUP_GPIO,
    WAKEUP_POWERON,
    WAKEUP_UNKNOWN
};

class SleepModule {
private:
    WakeupReason wakeupReason;

public:
    SleepModule();
    void begin();
    WakeupReason checkWakeup();
    WakeupReason getWakeupReason() { return wakeupReason; }
    void prepareSleep();
    void enterDeepSleep();
    void enterLightSleep(uint32_t sleepTimeMs = 0);
    static const char* reasonToString(WakeupReason reason);
};

#endif
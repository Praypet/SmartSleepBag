#ifndef PVDF_MODULE_H
#define PVDF_MODULE_H

#include <Arduino.h>
#include <driver/adc.h>
#include "config.h"

struct PVDFPacket {
    uint32_t timestamp;
    uint16_t points[PVDF_POINTS_PER_PACK];
    float body_temp;
    float env_temp;
    float env_humi;
    bool temp_realtime;
    bool env_realtime;
};

class PVDFModule {
private:
    uint16_t buffer[PVDF_BUFFER_SIZE];
    volatile uint32_t writeIndex;
    volatile bool packetReady;
    hw_timer_t* timer;
    
    void initADC();
    static void IRAM_ATTR onTimer();

public:
    PVDFModule();
    ~PVDFModule();
    bool begin();
    void start();
    void stop();
    bool isPacketReady();
    bool getPacket(PVDFPacket& packet, float bodyTemp, float envTemp, float envHumi);
    uint16_t getValue(int index);
    uint16_t getLatestValue();
    bool isSignalValid();
    uint32_t getWriteIndex() { return writeIndex; }
    
    float adcToVoltage(uint16_t adc_value) {
        float adc_voltage = (adc_value / 4095.0f) * 3.3f;
        return adc_voltage * PVDF_VOLTAGE_DIVIDER;
    }
    
    float getCurrentVoltage() {
        uint16_t val = getLatestValue();
        return adcToVoltage(val);
    }
};

#endif
#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// ==================== 版本信息 ====================
#define FIRMWARE_VERSION "1.0.0"
#define PROJECT_NAME "智能婴儿睡袋系统"

// ==================== 引脚定义 ====================
#define PIN_PVDF_DIGITAL 2
#define PIN_PVDF_ANALOG 4
#define PIN_I2C_SDA 8
#define PIN_I2C_SCL 9
#define I2C_CLOCK_SPEED 100000
#define PIN_I2S_DOUT 11
#define PIN_I2S_BCK 12
#define PIN_I2S_WS 13

// ==================== PVDF 采集参数 ====================
#define PVDF_SAMPLE_RATE 20
#define PVDF_POINTS_PER_PACK 100
#define PVDF_BUFFER_SIZE 400
#define PVDF_ADC_CHANNEL ADC1_CHANNEL_3
#define PVDF_ADC_ATTEN ADC_ATTEN_DB_11
#define PVDF_ADC_WIDTH ADC_WIDTH_BIT_12
#define PVDF_VOLTAGE_DIVIDER 2.0f
#define PVDF_ADC_REF_VOLTAGE 3.3f
#define PVDF_MODULE_VMIN 0.7f
#define PVDF_MODULE_VMAX 4.3f
#define PVDF_MODULE_VDC 2.0f
#define PVDF_SIGNAL_VALID_THRESHOLD 50

// ==================== 体温阈值 ====================
#define TEMP_NORMAL_MIN 36.5
#define TEMP_NORMAL_MAX 37.5
#define TEMP_CRITICAL_LOW 36.0
#define TEMP_CRITICAL_HIGH 38.0
#define TEMP_HYSTERESIS 0.1

// ==================== 环境阈值 ====================
#define ENV_TEMP_MIN 22.0
#define ENV_TEMP_MAX 26.0
#define ENV_TEMP_HYST 0.2
#define ENV_HUMI_MIN 40.0
#define ENV_HUMI_MAX 60.0
#define ENV_HUMI_HYST 1.0

// ==================== 采样间隔 ====================
#define INTERVAL_NORMAL 300000
#define INTERVAL_ABNORMAL 60000
#define INTERVAL_CRITICAL 30000

// ==================== 上传配置 ====================
#define UPLOAD_INTERVAL 30000
#define UPLOAD_BATCH_SIZE 6
#define WIFI_TIMEOUT 60
#define WIFI_RETRY_INTERVAL 10000

// ==================== 音频检测 ====================
#define SAMPLE_RATE 16000
#define AUDIO_BITS_PER_SAMPLE 16
#define CRY_THRESHOLD 3000
#define CRY_DURATION 2000
#define AUDIO_CHUNK_SIZE 1024

// ==================== 婴儿离开检测 ====================
#define LEAVE_TIMEOUT 300000
#define SIGNAL_CHECK_INTERVAL 1000

// ==================== 深度睡眠 ====================
#define WAKEUP_PIN PIN_PVDF_DIGITAL
#define WAKEUP_LEVEL 1
#define DEEP_SLEEP_DELAY 100

// ==================== 看门狗 ====================
#define WDT_TIMEOUT 60

// ==================== 数据队列 ====================
#define QUEUE_SIZE 50

// ==================== 音频配置 ====================
#define AUDIO_SAMPLE_RATE 16000
#define AUDIO_BITS_PER_SAMPLE 16
#define AUDIO_RECORD_DURATION 10000
#define AUDIO_POOL_SIZE 6

// ==================== WiFi 配置 ====================
#define WIFI_SSID "chenggong"
#define WIFI_PASSWORD "123456789"
#define SERVER_URL "http://192.168.163.217:8086/api/upload"

#endif
/*轻量级调试工具库：
提供分级别的调试日志输出（ERROR/WARN/INFO/DEBUG）
支持打印设备内存使用信息
支持测量代码块的执行时间
可以通过调整调试级别来控制日志输出的详细程度，减少不必要的打印开销*/

#ifndef DEBUG_UTILS_H
#define DEBUG_UTILS_H

#include <Arduino.h>

// 调试级别
#define DEBUG_LEVEL_NONE 0    // 不输出任何日志
#define DEBUG_LEVEL_ERROR 1   // 仅输出错误日志
#define DEBUG_LEVEL_WARN 2    // 输出错误+警告日志
#define DEBUG_LEVEL_INFO 3    // 输出错误+警告+信息日志
#define DEBUG_LEVEL_DEBUG 4   // 输出所有级别的日志（最详细）

// 设置当前调试级别（可以在 config.h 中配置）
#ifndef DEBUG_LEVEL
#define DEBUG_LEVEL DEBUG_LEVEL_INFO
#endif
// 调试宏
#if DEBUG_LEVEL >= DEBUG_LEVEL_ERROR
#define DEBUG_ERROR(fmt, ...) Serial.printf("[ERROR] " fmt "\n", ##__VA_ARGS__)
#else
#define DEBUG_ERROR(fmt, ...)
#endif
#if DEBUG_LEVEL >= DEBUG_LEVEL_WARN
#define DEBUG_WARN(fmt, ...) Serial.printf("[WARN] " fmt "\n", ##__VA_ARGS__)
#else
#define DEBUG_WARN(fmt, ...)
#endif
#if DEBUG_LEVEL >= DEBUG_LEVEL_INFO
#define DEBUG_INFO(fmt, ...) Serial.printf("[INFO] " fmt "\n", ##__VA_ARGS__)
#else
#define DEBUG_INFO(fmt, ...)
#endif
#if DEBUG_LEVEL >= DEBUG_LEVEL_DEBUG
#define DEBUG_DEBUG(fmt, ...) Serial.printf("[DEBUG] " fmt "\n", ##__VA_ARGS__)
#else
#define DEBUG_DEBUG(fmt, ...)
#endif
// 内存信息打印
void printMemoryInfo() {
DEBUG_INFO("Free heap: %u bytes", ESP.getFreeHeap());
if (ESP.getPsramSize() > 0) {
DEBUG_INFO("Free PSRAM: %u bytes", ESP.getFreePsram());
}
}
// 执行时间测量
class ScopeTimer {
private:
const char* name;
uint32_t startTime;
public:
ScopeTimer(const char* n) : name(n), startTime(micros()) {} ~ScopeTimer() {
uint32_t elapsed = micros() - startTime;
DEBUG_DEBUG("%s took %lu us", name, elapsed);
}
};
#define MEASURE_TIME(name) ScopeTimer timer_##__LINE__(name)
#endif
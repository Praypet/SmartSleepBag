#include "state_module.h"

StateModule::StateModule()
    : mainState(SYS_DEEP_SLEEP), tempState(TEMP_NORMAL), lastBodyTemp(37.0),
      envTempState(ENV_TEMP_NORMAL), envHumiState(ENV_HUMI_NORMAL),
      lastEnvTemp(25.0), lastEnvHumi(50.0), lastValidSignalTime(0) {}

void StateModule::begin() {
    lastValidSignalTime = millis();
}

void StateModule::updateMainState() {
    if (tempState == TEMP_LOW_CRITICAL || tempState == TEMP_HIGH_CRITICAL) {
        mainState = SYS_CRITICAL;
    } else if (tempState != TEMP_NORMAL ||
               envTempState != ENV_TEMP_NORMAL ||
               envHumiState != ENV_HUMI_NORMAL) {
        mainState = SYS_ABNORMAL;
    } else {
        mainState = SYS_NORMAL;
    }
}

void StateModule::updateTempState(BodyTempState state, float value) {
    tempState = state;
    lastBodyTemp = value;
    updateMainState();
}

void StateModule::updateEnvState(EnvTempState tState, EnvHumiState hState, float temp, float humi) {
    envTempState = tState;
    envHumiState = hState;
    lastEnvTemp = temp;
    lastEnvHumi = humi;
    updateMainState();
}

void StateModule::updateSignalValid(bool valid) {
    if (valid) {
        lastValidSignalTime = millis();
    }
}

SystemMainState StateModule::getMainState() {
    return mainState;
}

uint32_t StateModule::getCurrentInterval() {
    if (mainState == SYS_CRITICAL) {
        return INTERVAL_CRITICAL;
    } else if (mainState == SYS_ABNORMAL) {
        return INTERVAL_ABNORMAL;
    } else {
        return INTERVAL_NORMAL;
    }
}

bool StateModule::checkForAlert(AlertType& type, char* detail, size_t detailSize) {
    if (tempState == TEMP_LOW_CRITICAL) {
        type = ALERT_TEMP_ABNORMAL;
        snprintf(detail, detailSize, "低温危急: %.1f℃", lastBodyTemp);
        return true;
    }
    if (tempState == TEMP_HIGH_CRITICAL) {
        type = ALERT_TEMP_ABNORMAL;
        snprintf(detail, detailSize, "高温危急: %.1f℃", lastBodyTemp);
        return true;
    }
    if (envTempState != ENV_TEMP_NORMAL) {
        type = ALERT_ENV_ABNORMAL;
        snprintf(detail, detailSize, "环境温度%s: %.1f℃", 
                 envTempState == ENV_TEMP_LOW ? "过低" : "过高", lastEnvTemp);
        return true;
    }
    if (envHumiState != ENV_HUMI_NORMAL) {
        type = ALERT_ENV_ABNORMAL;
        snprintf(detail, detailSize, "环境湿度%s: %.0f%%", 
                 envHumiState == ENV_HUMI_LOW ? "过低" : "过高", lastEnvHumi);
        return true;
    }
    return false;
}

bool StateModule::isBabyLeaving() {
    return (millis() - lastValidSignalTime > LEAVE_TIMEOUT);
}

const char* StateModule::mainStateToString(SystemMainState state) {
    switch (state) {
        case SYS_DEEP_SLEEP: return "深度睡眠";
        case SYS_NORMAL: return "正常";
        case SYS_ABNORMAL: return "异常";
        case SYS_CRITICAL: return "危急";
        case SYS_UPLOADING: return "上传中";
        default: return "未知";
    }
}